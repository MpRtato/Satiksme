#laika ievade un pārbaude
print('Laiks: (hh:mm / hh mm / hhmm)')

laiks=0
while laiks==0:
    laiksi=input('>')

    laiksparb=(list(laiksi))
    if len(laiksparb) <4 or len(laiksparb)>5:
        print('Nepareiza sintakse!')

    elif len(laiksparb)==4:
        if laiksparb[0].isdigit() == False or laiksparb[1].isdigit() == False or laiksparb[2].isdigit() == False or laiksparb[3].isdigit() == False:
            print('Nepareiza sintakse!')

        else:
            laikssadal=list(laiksi)
            if laikssadal[0]=='0':
                if int(laikssadal[1])<5:
                    #print(pirmais attiesanas laiks)

                else:
                    laiks= laikssadal[1]+':'+laikssadal[2]+laikssadal[3]

            else:
                laiks = laikssadal[0] + laikssadal[1] + ':' + laikssadal[2] + laikssadal[3]



    elif laiksparb[0].isdigit() == False or laiksparb[1].isdigit() == False or laiksparb[3].isdigit() == False or laiksparb[4].isdigit() == False:
        print('Nepareiza sintakse!')

    else:

        i=0
        if ':' in laiksparb[2]:
            laiks=laiksi.split(':')
            laikshh = list(laiks[0])
            i=1

        elif ' ' in laiksparb[2]:
            laiks=laiksi.split()
            laikshh = list(laiks[0])
            i=1

        else:
            print('Nepareiza sintakse!')

        if i==1:
            if '0' not in laikshh[0]:
                laiks=':'.join(laiks)

            elif '0' in laikshh[0]:
                laikshh.pop(0)
                laiks.pop(0)
                laikshh.extend(laiks)
                laiks = ':'.join(laikshh)

print(laiks)