from bs4 import BeautifulSoup as BS
from requests_html import HTMLSession

#laika ievade un pārbaude
session = HTMLSession()
jslinksl = session.get('https://saraksti.rigassatiksme.lv/index.html#bus/31/a-b')

izm=0
while izm == 0:
    print('...')
    jslinksl.html.render(timeout=10, sleep=1)

    laiki = BS(jslinksl.html.html, "lxml")
    pirmlaiks1 = laiki.find('div', {"id": "divScheduleContentInner"})
    pirmlaiks2 = laiki.select('a.highfloor')
    izm =1 #len(pirmlaiks)

#print(laiki)
print(pirmlaiks1.text)
#print(pirmlaiks2)
